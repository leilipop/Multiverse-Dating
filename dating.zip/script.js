/* ========================================
   MULTIVERSE DATING - JAVASCRIPT
   Application de rencontre interdimensionnelle
   ======================================== */

// ========================================
// VARIABLES GLOBALES
// ========================================

const API_BASE_URL = 'https://rickandmortyapi.com/api/character';

// Tableaux pour gérer l'état de l'application
let currentCandidates = []; // Personnages actuels dans le deck
let myMatches = []; // Personnages likés
let currentIndex = 0; // Index du personnage actuel affiché

// URL pour la pagination
let nextPageUrl = null;

// Compteurs de statistiques
let likeCount = 0;
let passCount = 0;

// ========================================
// ÉLÉMENTS DOM
// ========================================

const searchForm = document.getElementById('searchForm');
const nameInput = document.getElementById('nameInput');
const statusSelect = document.getElementById('statusSelect');
const genderSelect = document.getElementById('genderSelect');
const speciesInput = document.getElementById('speciesInput');

const deckContainer = document.getElementById('deckContainer');
const actionButtons = document.getElementById('actionButtons');
const passBtn = document.getElementById('passBtn');
const likeBtn = document.getElementById('likeBtn');
const loadMoreBtn = document.getElementById('loadMoreBtn');

const matchesList = document.getElementById('matchesList');
const matchCount = document.getElementById('matchCount');

const likeCounter = document.getElementById('likeCounter');
const passCounter = document.getElementById('passCounter');

const characterModal = document.getElementById('characterModal');
const closeModal = document.getElementById('closeModal');

const darkModeToggle = document.getElementById('darkModeToggle');
const loadingOverlay = document.getElementById('loadingOverlay');

// ========================================
// INITIALISATION
// ========================================

document.addEventListener('DOMContentLoaded', () => {
    // Charger les matchs sauvegardés
    loadMatches();
    
    // Charger les statistiques
    loadStats();
    
    // Initialiser le mode sombre
    initDarkMode();
    
    // Écouteurs d'événements
    searchForm.addEventListener('submit', handleSearch);
    passBtn.addEventListener('click', () => handleSwipe('pass'));
    likeBtn.addEventListener('click', () => handleSwipe('like'));
    loadMoreBtn.addEventListener('click', loadMoreProfiles);
    closeModal.addEventListener('click', () => characterModal.close());
    darkModeToggle.addEventListener('change', toggleDarkMode);
    
    // Fermer le modal en cliquant en dehors
    characterModal.addEventListener('click', (e) => {
        if (e.target === characterModal) {
            characterModal.close();
        }
    });
    
    // Easter egg: Konami Code
    initKonamiCode();
});

// ========================================
// GESTION DU FORMULAIRE DE RECHERCHE
// ========================================

/**
 * Gère la soumission du formulaire de recherche
 * Construit l'URL avec les paramètres et lance la recherche
 */
async function handleSearch(e) {
    e.preventDefault();
    
    // Construire l'URL avec les paramètres
    const url = buildSearchUrl();
    
    console.log('URL de recherche:', url);
    
    // Afficher le loading
    showLoading(true);
    
    try {
        // Fetch des données
        const data = await fetchCharacters(url);
        
        if (data && data.results && data.results.length > 0) {
            // Réinitialiser le deck
            currentCandidates = data.results;
            currentIndex = 0;
            nextPageUrl = data.info.next;
            
            // Afficher le premier personnage
            renderCurrentCard();
            
            // Afficher les boutons d'action
            actionButtons.style.display = 'flex';
            
            // Afficher le bouton "Charger plus" si pagination disponible
            loadMoreBtn.style.display = nextPageUrl ? 'block' : 'none';
        } else {
            showNoResults();
        }
    } catch (error) {
        console.error('Erreur lors de la recherche:', error);
        showError('Erreur lors de la recherche. Veuillez réessayer.');
    } finally {
        showLoading(false);
    }
}

/**
 * Construit l'URL de recherche avec les paramètres du formulaire
 */
function buildSearchUrl() {
    const params = new URLSearchParams();
    
    // Ajouter les paramètres non vides
    if (nameInput.value.trim()) {
        params.append('name', nameInput.value.trim());
    }
    
    if (statusSelect.value) {
        params.append('status', statusSelect.value);
    }
    
    if (genderSelect.value) {
        params.append('gender', genderSelect.value);
    }
    
    if (speciesInput.value.trim()) {
        params.append('species', speciesInput.value.trim());
    }
    
    // Construire l'URL complète
    return `${API_BASE_URL}${params.toString() ? '?' + params.toString() : ''}`;
}

// ========================================
// FETCH API
// ========================================

/**
 * Récupère les personnages depuis l'API
 */
async function fetchCharacters(url) {
    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            if (response.status === 404) {
                return null; // Aucun personnage trouvé
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Erreur fetch:', error);
        throw error;
    }
}

// ========================================
// RENDU DES CARTES
// ========================================

/**
 * Affiche le personnage actuel sous forme de carte
 */
function renderCurrentCard() {
    if (currentIndex >= currentCandidates.length) {
        showEndOfDeck();
        return;
    }
    
    const character = currentCandidates[currentIndex];
    
    // Créer la carte HTML
    const cardHtml = `
        <div class="character-card" data-character="${character.name}">
            <div class="card-image-container">
                <img src="${character.image}" alt="${character.name}" class="card-image">
            </div>
            <div class="card-content">
                <div class="card-header">
                    <h2 class="card-name">${character.name}</h2>
                    <span class="card-id">#${character.id}</span>
                </div>
                <div class="card-badges">
                    <span class="badge status-${character.status.toLowerCase()}">${character.status}</span>
                    <span class="badge badge-species">${character.species}</span>
                    <span class="badge badge-gender">${character.gender}</span>
                </div>
                <div class="card-info">
                    <div class="info-row">
                        <span>🌍</span>
                        <span><strong>Origine:</strong> ${character.origin.name}</span>
                    </div>
                    <div class="info-row">
                        <span>📍</span>
                        <span><strong>Localisation:</strong> ${character.location.name}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    deckContainer.innerHTML = cardHtml;
}

/**
 * Affiche un message quand il n'y a plus de cartes
 */
function showEndOfDeck() {
    const endHtml = `
        <div class="end-message">
            <div class="welcome-icon">🎉</div>
            <h3>Fin du deck !</h3>
            <p>Vous avez vu tous les personnages disponibles.</p>
            ${nextPageUrl ? '<p>Cliquez sur "Charger plus de profils" pour continuer.</p>' : ''}
        </div>
    `;
    
    deckContainer.innerHTML = endHtml;
    actionButtons.style.display = 'none';
}

/**
 * Affiche un message quand aucun personnage n'est trouvé
 */
function showNoResults() {
    const noResultsHtml = `
        <div class="welcome-message">
            <div class="welcome-icon">👽</div>
            <h3>Personne dans cette dimension</h3>
            <p>Aucun personnage ne correspond à vos critères.</p>
            <p>Essayez de modifier vos filtres !</p>
        </div>
    `;
    
    deckContainer.innerHTML = noResultsHtml;
    actionButtons.style.display = 'none';
    loadMoreBtn.style.display = 'none';
}

/**
 * Affiche un message d'erreur
 */
function showError(message) {
    const errorHtml = `
        <div class="welcome-message">
            <div class="welcome-icon">⚠️</div>
            <h3>Erreur</h3>
            <p>${message}</p>
        </div>
    `;
    
    deckContainer.innerHTML = errorHtml;
    actionButtons.style.display = 'none';
}

// ========================================
// SYSTÈME DE SWIPE (LIKE/PASS)
// ========================================

/**
 * Gère le swipe (like ou pass)
 */
function handleSwipe(action) {
    if (currentIndex >= currentCandidates.length) return;
    
    const character = currentCandidates[currentIndex];
    const card = document.querySelector('.character-card');
    
    if (!card) return;
    
    if (action === 'like') {
        // Ajouter aux matchs
        addMatch(character);
        
        // Animation swipe right
        card.classList.add('swipe-right');
        
        // Incrémenter le compteur de likes
        likeCount++;
        updateStats();
    } else {
        // Animation swipe left
        card.classList.add('swipe-left');
        
        // Incrémenter le compteur de pass
        passCount++;
        updateStats();
    }
    
    // Passer au personnage suivant après l'animation
    setTimeout(() => {
        currentIndex++;
        renderCurrentCard();
    }, 600);
}

// ========================================
// GESTION DES MATCHS
// ========================================

/**
 * Ajoute un personnage aux matchs
 */
function addMatch(character) {
    // Vérifier que le personnage n'est pas déjà dans les matchs
    if (!myMatches.find(match => match.id === character.id)) {
        myMatches.push(character);
        saveMatches();
        renderMatches();
    }
}

/**
 * Sauvegarde les matchs dans le localStorage
 */
function saveMatches() {
    localStorage.setItem('myMatches', JSON.stringify(myMatches));
    updateMatchCount();
}

/**
 * Charge les matchs depuis le localStorage
 */
function loadMatches() {
    const stored = localStorage.getItem('myMatches');
    if (stored) {
        try {
            myMatches = JSON.parse(stored);
            renderMatches();
        } catch (error) {
            console.error('Erreur lors du chargement des matchs:', error);
            myMatches = [];
        }
    }
}

/**
 * Affiche la liste des matchs
 */
function renderMatches() {
    if (myMatches.length === 0) {
        matchesList.innerHTML = `
            <div class="empty-matches">
                <div class="empty-icon">💔</div>
                <p>Aucun match pour le moment</p>
                <p class="empty-subtext">Swipez pour trouver l'amour !</p>
            </div>
        `;
        return;
    }
    
    const matchesHtml = myMatches.map(match => `
        <div class="match-item" onclick="showCharacterDetails(${match.id})">
            <img src="${match.image}" alt="${match.name}" class="match-avatar">
            <div class="match-name">${match.name}</div>
            <button class="match-remove" onclick="event.stopPropagation(); removeMatch(${match.id})">×</button>
        </div>
    `).join('');
    
    matchesList.innerHTML = matchesHtml;
    updateMatchCount();
}

/**
 * Supprime un match
 */
function removeMatch(characterId) {
    myMatches = myMatches.filter(match => match.id !== characterId);
    saveMatches();
    renderMatches();
}

/**
 * Met à jour le compteur de matchs
 */
function updateMatchCount() {
    matchCount.textContent = myMatches.length;
}

// ========================================
// MODAL DE DÉTAILS
// ========================================

/**
 * Affiche les détails d'un personnage dans une modal
 */
async function showCharacterDetails(characterId) {
    showLoading(true);
    
    try {
        // Chercher d'abord dans les matchs
        let character = myMatches.find(match => match.id === characterId);
        
        // Si pas trouvé dans les matchs, fetch depuis l'API
        if (!character) {
            const response = await fetch(`${API_BASE_URL}/${characterId}`);
            if (!response.ok) throw new Error('Personnage non trouvé');
            character = await response.json();
        }
        
        // Remplir la modal
        document.getElementById('modalImage').src = character.image;
        document.getElementById('modalImage').alt = character.name;
        document.getElementById('modalName').textContent = character.name;
        document.getElementById('modalStatus').textContent = character.status;
        document.getElementById('modalStatus').className = `badge status-${character.status.toLowerCase()}`;
        document.getElementById('modalSpecies').textContent = character.species;
        document.getElementById('modalSpecies').className = 'badge badge-species';
        document.getElementById('modalGender').textContent = character.gender;
        document.getElementById('modalGender').className = 'badge badge-gender';
        document.getElementById('modalOrigin').textContent = character.origin.name;
        document.getElementById('modalLocation').textContent = character.location.name;
        document.getElementById('modalEpisodes').textContent = character.episode ? character.episode.length : 'N/A';
        
        // Ouvrir la modal
        characterModal.showModal();
    } catch (error) {
        console.error('Erreur lors du chargement des détails:', error);
        alert('Impossible de charger les détails du personnage');
    } finally {
        showLoading(false);
    }
}

// ========================================
// PAGINATION
// ========================================

/**
 * Charge plus de profils depuis la page suivante
 */
async function loadMoreProfiles() {
    if (!nextPageUrl) return;
    
    showLoading(true);
    
    try {
        const data = await fetchCharacters(nextPageUrl);
        
        if (data && data.results && data.results.length > 0) {
            // Ajouter les nouveaux personnages au deck
            currentCandidates.push(...data.results);
            
            // Mettre à jour l'URL de pagination
            nextPageUrl = data.info.next;
            
            // Masquer le bouton si plus de pages
            loadMoreBtn.style.display = nextPageUrl ? 'block' : 'none';
            
            // Si on était à la fin du deck, afficher la nouvelle carte
            if (currentIndex >= currentCandidates.length - data.results.length) {
                renderCurrentCard();
                actionButtons.style.display = 'flex';
            }
        }
    } catch (error) {
        console.error('Erreur lors du chargement de plus de profils:', error);
        alert('Erreur lors du chargement. Veuillez réessayer.');
    } finally {
        showLoading(false);
    }
}

// ========================================
// STATISTIQUES
// ========================================

/**
 * Met à jour l'affichage des statistiques
 */
function updateStats() {
    likeCounter.textContent = likeCount;
    passCounter.textContent = passCount;
    saveStats();
}

/**
 * Sauvegarde les statistiques dans le localStorage
 */
function saveStats() {
    localStorage.setItem('stats', JSON.stringify({
        likes: likeCount,
        passes: passCount
    }));
}

/**
 * Charge les statistiques depuis le localStorage
 */
function loadStats() {
    const stored = localStorage.getItem('stats');
    if (stored) {
        try {
            const stats = JSON.parse(stored);
            likeCount = stats.likes || 0;
            passCount = stats.passes || 0;
            updateStats();
        } catch (error) {
            console.error('Erreur lors du chargement des stats:', error);
        }
    }
}

// ========================================
// MODE SOMBRE
// ========================================

/**
 * Initialise le mode sombre
 */
function initDarkMode() {
    const isDark = localStorage.getItem('darkMode') !== 'false';
    darkModeToggle.checked = !isDark;
    
    if (!isDark) {
        document.body.classList.add('light-mode');
    }
}

/**
 * Toggle le mode sombre
 */
function toggleDarkMode() {
    const isLightMode = darkModeToggle.checked;
    
    if (isLightMode) {
        document.body.classList.add('light-mode');
        localStorage.setItem('darkMode', 'false');
    } else {
        document.body.classList.remove('light-mode');
        localStorage.setItem('darkMode', 'true');
    }
}

// ========================================
// LOADING
// ========================================

/**
 * Affiche ou masque l'overlay de chargement
 */
function showLoading(show) {
    loadingOverlay.style.display = show ? 'flex' : 'none';
}

// ========================================
// EASTER EGGS
// ========================================

/**
 * Konami Code Easter Egg
 * Sequence: ↑ ↑ ↓ ↓ ← → ← → B A
 */
function initKonamiCode() {
    const konamiCode = [
        'ArrowUp', 'ArrowUp',
        'ArrowDown', 'ArrowDown',
        'ArrowLeft', 'ArrowRight',
        'ArrowLeft', 'ArrowRight',
        'b', 'a'
    ];
    
    let konamiIndex = 0;
    
    document.addEventListener('keydown', (e) => {
        const key = e.key.toLowerCase();
        
        if (key === konamiCode[konamiIndex].toLowerCase()) {
            konamiIndex++;
            
            if (konamiIndex === konamiCode.length) {
                activateKonamiEasterEgg();
                konamiIndex = 0;
            }
        } else {
            konamiIndex = 0;
        }
    });
}

/**
 * Active l'easter egg Konami
 */
function activateKonamiEasterEgg() {
    // Recherche automatique de Rick Sanchez
    nameInput.value = 'Rick';
    statusSelect.value = 'alive';
    
    // Déclencher la recherche
    searchForm.dispatchEvent(new Event('submit'));
    
    // Message d'easter egg
    setTimeout(() => {
        alert('🌀 Wubba Lubba Dub Dub! 🌀\n\nVous avez trouvé l\'easter egg Konami!\nPréparez-vous à rencontrer Rick Sanchez!');
    }, 500);
}

/**
 * Easter egg spécial pour Rick Sanchez
 * Déclenché automatiquement quand Rick apparaît
 */
function checkForRickEasterEgg() {
    const card = document.querySelector('.character-card[data-character="Rick Sanchez"]');
    if (card) {
        console.log('🌀 Wubba Lubba Dub Dub! Rick Sanchez détecté!');
        
        // Effet spécial portal
        card.style.animation = 'rickGlow 2s ease-in-out infinite';
    }
}

// Vérifier les easter eggs après chaque rendu
const originalRenderCurrentCard = renderCurrentCard;
renderCurrentCard = function() {
    originalRenderCurrentCard();
    setTimeout(checkForRickEasterEgg, 100);
};

// ========================================
// GESTION DU CLAVIER
// ========================================

/**
 * Gestion des raccourcis clavier
 */
document.addEventListener('keydown', (e) => {
    // Ignorer si on tape dans un input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') {
        return;
    }
    
    // Flèche gauche ou X = Pass
    if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'x') {
        if (actionButtons.style.display === 'flex') {
            handleSwipe('pass');
        }
    }
    
    // Flèche droite ou L = Like
    if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'l') {
        if (actionButtons.style.display === 'flex') {
            handleSwipe('like');
        }
    }
    
    // Échap = Fermer modal
    if (e.key === 'Escape' && characterModal.open) {
        characterModal.close();
    }
});

// ========================================
// FONCTIONS UTILITAIRES
// ========================================

/**
 * Formatte un nombre avec séparateurs de milliers
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

/**
 * Anime un nombre (compteur)
 */
function animateNumber(element, from, to, duration = 500) {
    const start = Date.now();
    const step = (to - from) / duration;
    
    function update() {
        const now = Date.now();
        const elapsed = now - start;
        
        if (elapsed < duration) {
            element.textContent = Math.floor(from + step * elapsed);
            requestAnimationFrame(update);
        } else {
            element.textContent = to;
        }
    }
    
    update();
}

console.log('🌌 Multiverse Dating initialisé!');
console.log('💡 Astuce: Utilisez les flèches du clavier pour swiper!');
console.log('💡 Astuce: Essayez le Konami Code pour un easter egg! ↑↑↓↓←→←→BA');
