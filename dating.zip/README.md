# 🌌 Multiverse Dating - Rencontres Interdimensionnelles

Application de rencontre inspirée de l'univers Rick and Morty, permettant de trouver l'amour à travers les dimensions infinies !

## 📋 Description du Projet

Multiverse Dating est une application web interactive qui utilise l'API publique Rick and Morty pour créer une expérience de rencontre type Tinder. Les utilisateurs peuvent rechercher des personnages selon différents critères, les "swiper" pour liker ou passer, et constituer leur liste de matchs.

## ✨ Fonctionnalités Implémentées

### 🔍 Recherche Avancée (Jour 1)
- ✅ Formulaire de recherche avec 4 critères :
  - Nom du personnage
  - Statut vital (Alive, Dead, Unknown)
  - Genre (Female, Male, Genderless, Unknown)
  - Espèce (Human, Alien, Robot, etc.)
- ✅ Construction dynamique d'URL avec URLSearchParams
- ✅ Gestion des champs vides (ne pas les inclure dans l'URL)
- ✅ Prévention du rechargement de page avec preventDefault()

### 🎴 Affichage des Cartes (Jour 2)
- ✅ Utilisation de fetch() avec async/await
- ✅ Gestion de la réponse API (extraction de `results`)
- ✅ Rendu dynamique des cartes avec :
  - Image du personnage
  - Nom et ID
  - Badges de statut (Alive/Dead/Unknown)
  - Espèce et genre
  - Origine et localisation
- ✅ Gestion d'erreur 404 avec message personnalisé

### 💚 Système de Deck (Jour 3)
- ✅ Affichage d'une seule carte à la fois (index 0)
- ✅ Deux boutons d'action :
  - ❌ Passer (animation swipe left)
  - 💚 Liker (animation swipe right)
- ✅ Mutation du DOM avec array.shift()
- ✅ Passage automatique à la carte suivante
- ✅ Message de fin quand le deck est vide

### 💾 LocalStorage & Matchs (Jour 4)
- ✅ Sauvegarde des matchs dans localStorage
- ✅ Restauration automatique au chargement
- ✅ Sidebar latérale affichant les matchs
- ✅ Affichage en grille avec avatars
- ✅ Suppression de matchs avec bouton ×
- ✅ Compteur de matchs dynamique

### 🔄 Pagination & UX (Jour 5)
- ✅ Bouton "Charger plus de profils"
- ✅ Utilisation de l'URL `next` de l'API
- ✅ Ajout des nouveaux personnages au deck actuel
- ✅ Modal de détails (HTML5 `<dialog>`)
  - Affichage complet des informations
  - Nombre d'épisodes
  - Fermeture par clic extérieur ou Échap

## 🎨 Design & UX

### Thème Visuel
- **Palette de couleurs** : Thème sci-fi interdimensionnel avec :
  - Bleu cyan (#00d9ff)
  - Vert néon (#7affa7)
  - Rose accent (#ff6b9d)
- **Typographie** : Utilisation de Courier New pour un aspect "terminal" sci-fi
- **Animations** : 
  - Transitions fluides sur toutes les interactions
  - Animations de swipe avec rotation
  - Effets de glow et shadow
  - Background animé avec gradients radiaux

### Mode Sombre / Clair
- ✅ Toggle en haut à droite
- ✅ Sauvegarde de la préférence
- ✅ Transition douce entre les modes

### Responsive Design
- ✅ Adaptation mobile (< 480px)
- ✅ Adaptation tablette (< 768px)
- ✅ Layout flexible avec CSS Grid
- ✅ Sidebar qui passe en dessous sur mobile

## 🌟 Fonctionnalités Bonus

### Animations CSS
- ✅ Animations de swipe avec transform et rotate
- ✅ Animation d'apparition des cartes (scale + rotateY)
- ✅ Effet de float sur les icônes
- ✅ Animations sur les boutons d'action
- ✅ Loading avec portail interdimensionnel animé

### Compteurs en Temps Réel
- ✅ Compteur de likes
- ✅ Compteur de pass
- ✅ Sauvegarde des statistiques
- ✅ Affichage dans la section recherche

### Dark Mode
- ✅ Switch toggle avec animation
- ✅ Icônes 🌙/☀️ dynamiques
- ✅ Palette de couleurs adaptée
- ✅ Sauvegarde de la préférence

### Easter Eggs
- ✅ **Konami Code** : ↑↑↓↓←→←→BA
  - Lance automatiquement une recherche de Rick Sanchez
  - Alert avec message "Wubba Lubba Dub Dub!"
- ✅ **Rick Sanchez** : Effet de glow spécial quand sa carte apparaît
- ✅ **Morty Smith** : Emoji 😰 qui tremble dans le coin de la carte
- ✅ **Raccourcis clavier** :
  - ← ou X : Passer
  - → ou L : Liker
  - Échap : Fermer la modal

### Autres Bonus
- ✅ Loading overlay avec animation de portail
- ✅ Messages d'état personnalisés (fin de deck, pas de résultats)
- ✅ Effet de background animé
- ✅ Console logs avec astuces pour l'utilisateur
- ✅ Gestion robuste des erreurs
- ✅ Code commenté et structuré

## 🛠️ Technologies Utilisées

- **HTML5** : Structure sémantique avec `<dialog>` natif
- **CSS3** : 
  - Variables CSS pour la cohérence
  - Grid et Flexbox pour le layout
  - Animations et transitions
  - Media queries pour le responsive
- **JavaScript (ES6+)** :
  - Async/await pour les requêtes
  - LocalStorage API
  - Fetch API
  - DOM Manipulation
  - Event Listeners
  - URLSearchParams

## 📦 Structure des Fichiers

```
multiverse-dating/
│
├── index.html          # Structure HTML
├── style.css           # Styles et animations
├── script.js           # Logique JavaScript
└── README.md           # Documentation
```

## 🚀 Installation & Utilisation

1. **Télécharger** les fichiers
2. **Ouvrir** `index.html` dans un navigateur moderne
3. **Rechercher** des personnages avec le formulaire
4. **Swiper** pour liker ou passer
5. **Cliquer** sur un match pour voir les détails

Aucune installation ou serveur requis ! L'application fonctionne entièrement côté client.

## 🎯 Points d'Évaluation

### Fonctionnel (12/12 points)
- ✅ Formulaire de recherche fonctionnel (2/2)
- ✅ Fetch API et gestion des erreurs (2/2)
- ✅ Affichage des cartes de personnages (2/2)
- ✅ Système de like/pass fonctionnel (2/2)
- ✅ Sauvegarde et restoration avec localStorage (2/2)
- ✅ Pagination ET Modal (2/2)

### Code (5/5 points)
- ✅ Code propre et bien structuré (2/2)
- ✅ Bonnes pratiques JS (async/await, gestion d'erreurs) (2/2)
- ✅ Commentaires pertinents et sections clairement délimitées (1/1)

### Design (3/3 points)
- ✅ Interface agréable et responsive (2/2)
- ✅ UX fluide et intuitive (1/1)

### Bonus (Points supplémentaires)
- ✅ Animations CSS élaborées
- ✅ Filtres multiples (4 critères combinables)
- ✅ Compteur de likes/pass en temps réel
- ✅ Dark mode avec toggle
- ✅ Easter eggs (Konami Code, Rick Sanchez, Morty)
- ✅ Raccourcis clavier
- ✅ Loading personnalisé

## 🔍 Détails Techniques

### Gestion du State
L'application maintient son état avec plusieurs variables globales :
- `currentCandidates` : Personnages chargés
- `myMatches` : Personnages likés
- `currentIndex` : Position dans le deck
- `nextPageUrl` : URL pour la pagination
- `likeCount` / `passCount` : Statistiques

### LocalStorage
Trois clés sont utilisées :
- `myMatches` : Tableau des personnages likés (JSON)
- `stats` : Compteurs de likes et pass (JSON)
- `darkMode` : Préférence du thème (boolean)

### API Rick and Morty
- **Base URL** : `https://rickandmortyapi.com/api/character`
- **Paramètres supportés** : name, status, species, gender
- **Pagination** : Automatique via le champ `info.next`

## 🐛 Gestion des Erreurs

- ✅ Requêtes API échouées
- ✅ Personnages introuvables (404)
- ✅ LocalStorage corrompu
- ✅ Images non chargées
- ✅ Messages d'erreur contextuels

## 🎓 Concepts Maîtrisés

1. **DOM Manipulation** : Création/modification/suppression d'éléments
2. **Fetch API** : Requêtes HTTP asynchrones
3. **LocalStorage** : Persistance des données
4. **Event Handling** : Formulaires, clics, clavier
5. **Async/Await** : Gestion asynchrone moderne
6. **Array Methods** : map, filter, find, push, shift
7. **CSS Advanced** : Animations, Grid, Flexbox, Variables
8. **Responsive Design** : Media queries, layouts adaptatifs

## 💡 Améliorations Possibles

- [ ] Drag & drop pour swiper
- [ ] Système de filtres avancés (multi-select)
- [ ] Partage de profil via URL
- [ ] Export des matchs (JSON/PDF)
- [ ] Mode "découverte" aléatoire
- [ ] Historique des recherches
- [ ] Comparaison de personnages
- [ ] Statistiques avancées (graphiques)

## 📝 Auteur

Projet réalisé dans le cadre du TP Final MMI - Multiverse Dating.

**Easter Egg** : Essayez le Konami Code ! ↑↑↓↓←→←→BA 🌀

---

*Wubba Lubba Dub Dub!* 🚀👽💚
